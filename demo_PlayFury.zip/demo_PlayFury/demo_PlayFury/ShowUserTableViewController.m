//
//  ShowUserTableViewController.m
//  demo_PlayFury
//
//  Created by mac on 3/18/16.
//  Copyright © 2016 Razer. All rights reserved.
//

#import "ShowUserTableViewController.h"
#import "Cell/CellShowUserTableViewCell.h"
#import "ObjectUser.h"

@interface ShowUserTableViewController (){
    NSMutableArray *arrayUser;
    UIActivityIndicatorView *activityView;
}

@end

@implementation ShowUserTableViewController
@synthesize token;
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"User";
    [self ShowAllUser:token];
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    
    activityView = [[UIActivityIndicatorView alloc]
                    initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    
    activityView.center=self.view.center;
    [activityView setColor:[UIColor blueColor]];
    [self.view addSubview:activityView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [arrayUser count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellIdentifier = @"CellUser";
    CellShowUserTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (!cell) {
        cell = [[CellShowUserTableViewCell alloc]init];
    }
    
    User *user = [arrayUser objectAtIndex:indexPath.row];
    cell.lblName.text = user.name;
    cell.lblEmail.text = user.email;
    
    cell.imageLogo.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:user.avatar]]];
    cell.imageLogo.layer.shadowOpacity = 0.65;
    
    return cell;
}



#pragma mark - show all job
-(void)ShowAllUser:(NSString *)AccessToken{
    [activityView startAnimating];
    arrayUser = [[NSMutableArray alloc]init];
    NSString *urlString = [NSString stringWithFormat:@"http://54.255.201.10:9000/users"];
    NSString *parameter = [NSString stringWithFormat:@"m %@",AccessToken];
    
    NSURL *url = [NSURL URLWithString:urlString];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    [request setHTTPMethod:@"GET"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request setValue:parameter forHTTPHeaderField:@"Authorization"];
    
    NSURLSession *session = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    [[session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        NSLog(@"%@",response);
        if ([data length] > 0 && !error)
        {
            NSDictionary *dicAllUser  = [NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
            for (NSDictionary *dicUser in dicAllUser ) {
                User *user = [[User alloc]init];
                user.name = [dicUser objectForKey:@"name"];
                user.email = [dicUser objectForKey:@"email"];
                user.avatar = [dicUser objectForKey:@"avatar"];
                [arrayUser addObject:user];
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.tableView reloadData];
                [activityView stopAnimating];
            });
        }
    }] resume];
}

@end
