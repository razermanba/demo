//
//  ObjectUser.h
//  demo_PlayFury
//
//  Created by mac on 3/18/16.
//  Copyright © 2016 Razer. All rights reserved.
//

#import <Foundation/Foundation.h>

@class Token ;
@class User;


@interface Token : NSObject
{
    /* elements */
    NSString *token;
    User *user;
    /* attributes */
}
@property (retain, nonatomic) NSString * token;
@property (retain, nonatomic) User * user;

/* attributes */
- (NSDictionary *)attributes;

@end

@interface User : NSObject
{
    /* elements */
    NSString *salt;
    NSString *provider;
    NSString *name;
    NSString *email;
    NSString *password;
    NSString *_id;
    NSString *__v;
    NSString *created;
    NSString *avatar;
    /* attributes */
}
@property (retain, nonatomic) NSString * salt;
@property (retain, nonatomic) NSString * provider;
@property (retain, nonatomic) NSString * name;
@property (retain, nonatomic) NSString * email;
@property (retain, nonatomic) NSString * password;
@property (retain, nonatomic) NSString * _id;
@property (retain, nonatomic) NSString * __v;
@property (retain, nonatomic) NSString * created;
@property (retain, nonatomic) NSString * avatar;


/* attributes */
- (NSDictionary *)attributes;

@end
