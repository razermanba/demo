//
//  ShowUserTableViewController.h
//  demo_PlayFury
//
//  Created by mac on 3/18/16.
//  Copyright © 2016 Razer. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShowUserTableViewController : UITableViewController

@property (nonatomic,strong) NSString *token;

@end
