//
//  CreateAccountTableViewController.h
//  demo_PlayFury
//
//  Created by mac on 3/18/16.
//  Copyright © 2016 Razer. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CreateAccountTableViewController : UITableViewController
@property (weak, nonatomic) IBOutlet UITextField *txtName;
@property (weak, nonatomic) IBOutlet UITextField *txtEmail;
@property (weak, nonatomic) IBOutlet UITextField *txtPassword;
- (IBAction)actionDone:(id)sender;

@end
