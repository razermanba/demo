//
//  ObjectUser.m
//  demo_PlayFury
//
//  Created by mac on 3/18/16.
//  Copyright © 2016 Razer. All rights reserved.
//

#import "ObjectUser.h"

@implementation Token : NSObject

@synthesize token;
@synthesize user;

- (NSDictionary *)attributes
{
    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
    
    return attributes;
}

@end

@implementation User : NSObject

@synthesize __v;
@synthesize salt;
@synthesize password;
@synthesize provider;
@synthesize _id;
@synthesize created;
@synthesize avatar;
@synthesize name;
@synthesize email;

- (NSDictionary *)attributes
{
    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
    
    return attributes;
}

@end