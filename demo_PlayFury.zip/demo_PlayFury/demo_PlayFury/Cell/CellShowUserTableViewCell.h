//
//  CellShowUserTableViewCell.h
//  demo_PlayFury
//
//  Created by mac on 3/18/16.
//  Copyright © 2016 Razer. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CellShowUserTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imageLogo;
@property (weak, nonatomic) IBOutlet UILabel *lblName;
@property (weak, nonatomic) IBOutlet UILabel *lblEmail;

@end
