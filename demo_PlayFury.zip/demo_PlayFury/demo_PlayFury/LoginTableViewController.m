//
//  LoginTableViewController.m
//  demo_PlayFury
//
//  Created by mac on 3/18/16.
//  Copyright © 2016 Razer. All rights reserved.
//

#import "LoginTableViewController.h"
#import "ObjectUser.h"
#import "ShowUserTableViewController.h"

@interface LoginTableViewController (){
    Token *token;
    UIActivityIndicatorView *activityView;
}

@end

@implementation LoginTableViewController
@synthesize txtEmail,txtPassword,btnCreate,btnLogin;

- (void)viewDidLoad {
    [super viewDidLoad];
    //annotation button create
    btnCreate.layer.borderColor = [UIColor whiteColor].CGColor;
    
    btnCreate.layer.borderWidth = 1.0;
    
    btnCreate.layer.cornerRadius = 10;
    //annotation button Login
    btnLogin.layer.borderColor = [UIColor whiteColor].CGColor;
    
    btnLogin.layer.borderWidth = 1.0;
    
    btnLogin.layer.cornerRadius = 10;
    
    activityView = [[UIActivityIndicatorView alloc]
                    initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    
    activityView.center=self.view.center;
    [activityView setColor:[UIColor blueColor]];
    [self.view addSubview:activityView];


}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source


- (IBAction)actionLogin:(id)sender {
    [activityView startAnimating];

    [self.txtEmail resignFirstResponder];
    [self.txtPassword resignFirstResponder];
    NSDictionary *loginAccount = @{@"email" : txtEmail.text,
                                   @"password" : txtPassword.text};
    
    NSData *json = [NSJSONSerialization dataWithJSONObject:loginAccount options:NSJSONWritingPrettyPrinted error:nil];
    
    
    NSString *urlString = [NSString stringWithFormat:@"http://54.255.201.10:9000/auth/signin"];
    NSURL *url = [NSURL URLWithString:urlString];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    [request setHTTPMethod:@"POST"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request setHTTPBody:json];
    
    NSURLSession *session = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    [[session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        NSDictionary *dicToken  = [NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
        NSLog(@"%@",dicToken);
        if ([data length] > 0 && !error)
        {
            token = [[Token alloc]init];
            token.token = [dicToken objectForKey:@"token"];
            
            if (token.token.length > 0) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    [activityView stopAnimating];
                    [self performSegueWithIdentifier:@"showUser" sender:self];
                });
            }else{
                NSString *message = [dicToken objectForKey:@"message"];
                
                UIAlertController * alert=   [UIAlertController
                                              alertControllerWithTitle:@"Error"
                                              message:message
                                              preferredStyle:UIAlertControllerStyleAlert];
                UIAlertAction* noButton = [UIAlertAction
                                           actionWithTitle:@"OK"
                                           style:UIAlertActionStyleDefault
                                           handler:^(UIAlertAction * action)
                                           {
                                               //Handel no, thanks button
                                               
                                           }];
                
                [alert addAction:noButton];
                dispatch_async(dispatch_get_main_queue(), ^{
                    [activityView stopAnimating];
                    [self presentViewController:alert animated:YES completion:nil];
                });
            }
        }
    }] resume];
}

- (IBAction)actionCreateAccount:(id)sender {
    [self performSegueWithIdentifier:@"CreateAccount" sender:self];
}

#pragma mark - prepareForSegue
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if ([segue.identifier isEqualToString:@"showUser"]){
        ShowUserTableViewController *showUser = [segue destinationViewController];
        showUser.token = token.token;
    }
}


@end
