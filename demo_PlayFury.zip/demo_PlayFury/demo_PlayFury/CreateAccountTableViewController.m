//
//  CreateAccountTableViewController.m
//  demo_PlayFury
//
//  Created by mac on 3/18/16.
//  Copyright © 2016 Razer. All rights reserved.
//

#import "CreateAccountTableViewController.h"

@interface CreateAccountTableViewController (){
    UIActivityIndicatorView *activityView;
}

@end

@implementation CreateAccountTableViewController
@synthesize txtEmail,txtName,txtPassword;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    
    activityView = [[UIActivityIndicatorView alloc]
                    initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    
    activityView.center=self.view.center;
    [activityView setColor:[UIColor blueColor]];
    [self.view addSubview:activityView];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)actionDone:(id)sender {
    [activityView startAnimating];
    [txtEmail resignFirstResponder];
    [txtName resignFirstResponder];
    [txtPassword resignFirstResponder];
    NSDictionary *loginAccount = @{  @"name" : txtName.text,
                                     @"email" : txtEmail.text,
                                     @"password" : txtPassword.text};
    
    NSData *json = [NSJSONSerialization dataWithJSONObject:loginAccount options:NSJSONWritingPrettyPrinted error:nil];
    
    
    NSString *urlString = [NSString stringWithFormat:@"http://54.255.201.10:9000/create"];
    NSURL *url = [NSURL URLWithString:urlString];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    [request setHTTPMethod:@"POST"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request setHTTPBody:json];
    
    NSURLSession *session = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    [[session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        NSDictionary *dicToken  = [NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
        NSLog(@"%@",dicToken);
        if ([data length] > 0 && !error)
        {
            if ([dicToken count] > 0) {
                NSString *message = [dicToken objectForKey:@"message"];
                if (message.length == 0) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [activityView stopAnimating];
                        [self.navigationController popViewControllerAnimated:YES];
                    });
                    
                }else{
                    UIAlertController * alert=   [UIAlertController
                                                  alertControllerWithTitle:@"Error"
                                                  message:message
                                                  preferredStyle:UIAlertControllerStyleAlert];
                    UIAlertAction* noButton = [UIAlertAction
                                               actionWithTitle:@"OK"
                                               style:UIAlertActionStyleDefault
                                               handler:^(UIAlertAction * action)
                                               {
                                                   //Handel no, thanks button
                                                   
                                               }];
                    
                    [alert addAction:noButton];
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [activityView stopAnimating];
                        [self presentViewController:alert animated:YES completion:nil];
                    });
                    
                }
            }
        }
    }] resume];
}
@end
